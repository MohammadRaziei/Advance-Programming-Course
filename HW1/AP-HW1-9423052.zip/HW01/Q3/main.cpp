#include <iostream>

double flr(double*, int l ,int r);
double print_calc(double* ,int);
double print(double*, int l, int r);
int main()
{
	size_t n{};
	std::cout << "Please enter n : \t";
	std::cin >> n;
	std::cout << "Now enter n numbers: " << std::endl;
	double* arr{new double [n]};
	for(size_t i{}; i < n ;i++)
		std::cin >> arr[i];
	
	print_calc(arr,n);

	
	delete[] arr;
	return 0;
}

double flr(double* arr, int l, int r)
{
	double sum{};
	for(int i{l-1}; i < r ; i++)
		sum += arr[i];
	return sum;
}

double print_calc(double* arr, int n)
{
	double ans{};
	for(int r{1}; r <= n; r++) 		// for 1<=r<=n
		for(int l{1}; l <= r; l++) 	// for 1<=l<=r
		{
			ans += print(arr,l,r);
			std::cout << ", ";
		}
	std::cout << "\b\b . \n\nans = " << ans << std::endl;
	return ans;
}
double print(double* arr,int l, int r)
{
	std::cout << "f(" << l << "," << r << ") = " << flr(arr,l,r) ;
	return flr(arr,l,r);
}

#include <iostream>
#include <cmath>
#include <iomanip>

double scant( double (*func)(double), double, double );
double poly(double);
double fun(double);
void choose(bool);

int main()
{
	bool a{};
	std::cout << "please enter 0 or 1...\n 0 : for 'coth(x)-log(x)'\n 1 : for 'x^3 + x^2 + x + 1' \n\n";
	std::cin >> a;
	choose(a) ;
	return 0;
}


double scant( double (*func)(double), double old, double older)
{
	static size_t CNT{};
	double New{};
	if ( std::isinf(func(old)) )
		New = older;
	else if ( std::isinf(func(older)) )
		New = old;
	else 
		New = (older*func(old) - old*func(older))/(func(old) - func(older));
	
	double err{(New - old)* old > 0 ? (New - old)/old : (old - New)/old };

	std::cout << CNT++ << "\t:" << std::fixed << std::setprecision( 8 )
		<< std::setw(20) << older << std::fixed << std::setprecision( 8 )
		<< std::setw(20) << old << std::fixed << std::setprecision( 8 )
		<< std::setw(20) << New << std::fixed << std::setprecision( 8 )
		<< std::setw(20) << err << std::endl;
 	std::cout.unsetf( std::ios::fixed );
	if( err > 0.0001 || std::isinf(err) )
	{
		New = scant(func,New, old);
	}
	return New;
}
double poly(double x)
{
	return pow(x, 3) + pow(x, 2) + x + 1;
}
double fun(double x)
{
	double exp2x{exp(2*x)};
	return (exp2x + 1 )/(exp2x - 1 )  - log(x);
}
void choose(bool x)
{
	double (*pf)(double){x?poly:fun};
        std::cout << std::endl << (x?"For 'x^3 + x^2 + x + 1' :":"For 'coth(x)-log(x)' :") << std::endl;
        std::cout << "stage" << "\t:"<< std::fixed << std::setprecision( 8 )
                << std::setw(20) << "Older num. " << std::fixed << std::setprecision( 8 )
                << std::setw(20) << "Old num. " << std::fixed << std::setprecision( 8 )
                << std::setw(20) << "New num. " << std::fixed << std::setprecision( 8 )
                << std::setw(20) << "error value" << std::endl;
        std::cout.unsetf( std::ios::fixed );
        double root{scant( pf, 0, 1)};
        std::cout << std::endl << "##############################\n"
                << "Done :)\n Root is  " << root << std::endl;
}

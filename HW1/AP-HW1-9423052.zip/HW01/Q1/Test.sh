#!/bin/sh
######################################################################################
#  __  __       _                                         _ ____           _      _  #
# |  \/  | ___ | |__   __ _ _ __ ___  _ __ ___   __ _  __| |  _ \ __ _ ___(_) ___(_) #
# | |\/| |/ _ \| '_ \ / _` | '_ ` _ \| '_ ` _ \ / _` |/ _` | |_) / _` |_  / |/ _ \ | #
# | |  | | (_) | | | | (_| | | | | | | | | | | | (_| | (_| |  _ < (_| |/ /| |  __/ | #
# |_|  |_|\___/|_| |_|\__,_|_| |_| |_|_| |_| |_|\__,_|\__,_|_| \_\__,_/___|_|\___|_| #
#                                                                                    #
######################################################################################
echo '
                                                     
                                                     
               AAA               PPPPPPPPPPPPPPPPP   
              A:::A              P::::::::::::::::P  
             A:::::A             P::::::PPPPPP:::::P 
            A:::::::A            PP:::::P     P:::::P
           A:::::::::A             P::::P     P:::::P
          A:::::A:::::A            P::::P     P:::::P
         A:::::A A:::::A           P::::PPPPPP:::::P 
        A:::::A   A:::::A          P:::::::::::::PP  
       A:::::A     A:::::A         P::::PPPPPPPPP    
      A:::::AAAAAAAAA:::::A        P::::P            
     A:::::::::::::::::::::A       P::::P            
    A:::::AAAAAAAAAAAAA:::::A      P::::P            
   A:::::A             A:::::A   PP::::::PP          
  A:::::A               A:::::A  P::::::::P          
 A:::::A                 A:::::A P::::::::P          
AAAAAAA                   AAAAAAAPPPPPPPPPP          
                                                     
      By @MohammadRaziei                                             
'                                                     
                                                     
                                                     
read -p "Please Enter Your UserName :       " username
read -p "Please Enter Your PassWord :       " password
                          
while [ "$username" != "APNew"  -o  "$password" != "APNew"  ] 
do
	echo 'Sorry! Check your information and retry.'
	read -p "Please Enter Your UserName :       " username
	read -p "Please Enter Your PassWord :       " password
	echo 
done
echo 'Signing succesfull



NOTICE:
1  >>  to create "'$PWD'/AP2018/Hello.cpp" and then exit
2  >>  to exit now
'
read -p 'Enter 1 or 2  :          ' key
while [ "$key" != "1" -a "$key" != "2" ] 

do	
	echo 'Invalid Key'
	read -p 'Try to enter 1 or 2 :    ' key
done
if [ $key = 1 ];then
	mkdir AP2018
	touch AP2018/Hello.cpp
fi
exit

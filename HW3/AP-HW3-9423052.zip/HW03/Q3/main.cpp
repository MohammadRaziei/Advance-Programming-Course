#include"vector.h"

int main()
{
Vector v{};
Vector v1{};
Vector v2{};
//Vector v3{};
v.push_back(1);
v.push_back(2);
v.push_back(3);
v.addFront(0);
v.removeFront();
//Vector v3{v};
v.Subvec(1); // v.Subvec(1) = 2
//std::cout << v[0] <<" " << v[1] << " " << v[2] << " " <<  v[3];
v[0] = 10;
v1 = v;
v.pop_back();
//v1.display();
v2 = v1 + v; // v2 = 1,2,3,1,2
std::cout << "size: " << v.size() << "\n";
std::cout << "max_size: " << v.max() << "\n";
v2.display();
}

/*
By			: @MohammadRaziei
std.num.	: 9423052
project		: HW03-Q3
title		: Vector
*/
#include <iostream>
class Vector;

				// list element type
class DNode 
{					// doubly linked list node
private:
	double elem;					// node element value
	DNode* prev;				// previous node in list
	DNode* next;				// next node in list
	friend class Vector;			// allow Vector access
};


class Vector {				// doubly linked list
public:
	Vector();				// constructor	
	Vector( const Vector&); 
	~Vector();				// destructor
	const Vector& operator= (const Vector&);
	Vector operator+ (const Vector& ) const;
	double& operator[] (size_t) const;
	bool empty() const;				// is list empty?
	const double& front() const;			// get front element
	const double& back() const;			// get back element
	void addFront(const double& e);		// add to front of list
	void push_back(const double& e);		// add to back of list
	void removeFront();				// remove from front
	void pop_back();				// remove from back
	void display() const;
	double& at(size_t) const;
	double& at(DNode*) const;
	double& Subvec(size_t) const;
	double max() const;
	size_t size() const;
private:					// local type definitions
	DNode* header;				// list sentinels
	DNode* trailer;
	size_t Size;
protected:					// local utilities
	void add(DNode* v, const double& e);		// insert new node before v
	void remove(DNode* v);			// remove node v
};


#include <cmath>
#include "vector.h"


Vector::Vector() : Size(0)
{			// constructor
	header = new DNode;				// create sentinels
	trailer = new DNode;
	header->next = trailer;			// have them point to each other
	trailer->prev = header;
}

Vector::Vector( const Vector& v ) : Vector() 
{			// copy constructor
	operator=(v);
}

Vector::~Vector() 
{			// destructor
	while (!empty()) removeFront();		// remove all but sentinels
	delete header;				// remove the sentinels
	delete trailer;
}

const Vector& Vector::operator= (const Vector& v)
{
	if (this==&v)
		return *this;
	
	while (!empty()) pop_back();		// remove all but sentinels
	for(DNode* p { v.header->next }; p != v.trailer ; p = p->next)
		push_back(p->elem);
	return *this;
}

Vector Vector::operator+ (const Vector& v) const
{
	Vector tmp { *this };
	for(DNode* p { v.header->next }; p != v.trailer ; p = p->next)
		tmp.push_back(p->elem);
	return tmp;
}

double& Vector::operator[] (size_t index) const
{
	return at(index);
}

void Vector::display() const
{
	for(DNode* p { header->next }; p != trailer ; p = p->next)
		std::cout << p->elem << "\t";
	std::cout << std::endl;
}
                               // insert new node before v
void Vector::add(DNode* v, const double& e) 
{
	++Size;
	DNode* u { new DNode };  u->elem = e;		// create a new node for e
	u->next = v;				// link u in between v
	u->prev = v->prev;				// ...and v->prev
	v->prev->next = u;
	v->prev = u;
}


void Vector::addFront(const double& e)	// add to front of list
{
	add(header->next, e); 
}


void Vector::push_back(const double& e)	// add to back of list
{
	add(trailer, e); 
}

void Vector::remove(DNode* v) 
{		// remove node v
	if (empty()) 
		return;
	--Size;
	DNode* u = v->prev;				// predecessor
	DNode* w = v->next;				// successor
	u->next = w;				// unlink v from list
	w->prev = u;
	delete v;
}


void Vector::removeFront()		// remove from font
{
	remove(header->next); 
}


void Vector::pop_back()		// remove from back
{
	remove(trailer->prev);
}

bool Vector::empty() const		// is list empty?
{
	return (header->next == trailer); 
}

double& Vector::at(DNode* pn) const
{
	return pn->elem;
}

double& Vector::at(size_t index) const
{
	DNode* p { header->next }; 
	if ( 2*index > Size)
	{
		p = trailer->prev;
		for(size_t i {Size}; --i > index ; p = p->next);
	}
	else
		for(size_t i {}; i++ < index ; p = p->next);
	
	return at(p);
}

double& Vector::Subvec(size_t index) const
{
	double tmp {at(index)};
	std::cout << "Subvec(" << index << ") = " << tmp << std::endl;
	return at(index);
}
size_t Vector::size() const
{
	return Size;
}

double Vector::max() const
{
	if(empty())
		return std::nanf("");
	double _max { header->next->elem };
	for(DNode* p { header->next }; p != trailer ; p = p->next)
		if(_max < p->elem )
			_max = p->elem;
	return _max;
}

const double& Vector::front() const	// get front element
{
	return header->next->elem; 
}


const double& Vector::back() const		// get back element
{
	return trailer->prev->elem;
}
